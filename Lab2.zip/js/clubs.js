$('.confirmation').on('click', function(){
    return confirm('Are you sure you want to delete this?')

});
//This is using the jquery class to run this predefined function of confirmation, which asks for yes or no after we opt for the delete option